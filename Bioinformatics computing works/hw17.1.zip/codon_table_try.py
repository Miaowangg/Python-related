import sys

def read_codons_from_filename(codonfile):
    try:
        data = {}
        with open(codonfile) as f:
            for line in f:
                sl = line.split()
                key = sl[0]
                value = sl[2]
                data[key] = value
        
        b1 = data['Base1']
        b2 = data['Base2']
        b3 = data['Base3']
        aa = data['AAs']
        st = data['Starts']

        codon_table = {}
        for i in range(len(aa)):
            codon = b1[i] + b2[i] + b3[i]
            is_init = (st[i] == 'M')
            codon_table[codon] = (aa[i], is_init)
        
        return codon_table
    except FileNotFoundError:
        print('Codon table file not found')
        sys.exit(1)

    except IOError:
        print("can't read codon table file")
        sys.exit(1)

def amino_acid(codon_table, codon):
    try:
        return codon_table.get(codon, ('X', False))[0]
    except TypeError:
        print("Error: Invalid codon or codon_table provided")
        return 'X'
    except KeyError:
        print('condon not in codon table')

def is_init(codon_table, codon):
    try:
        return codon_table.get(codon, (None, False))[1]
    except TypeError:
        print("Error: Invalid codon or codon_table provided")
        return False

def get_ambig_aa(codon_table, codon):
    try:
        if 'N' in codon:
            return 'X'
        return amino_acid(codon_table, codon)
    except TypeError:
        print("Error: Invalid codon or codon_table provided")
        return 'X'

def translate(codon_table, seq, frame):
    try:
        seq = seq.upper()
        seq_len = len(seq)
        aaseq = []
        for i in range(frame - 1, seq_len, 3):
            codon = seq[i:i+3]
            if len(codon) == 3:
                aa = get_ambig_aa(codon_table, codon)
                aaseq.append(aa)
        return ''.join(aaseq)
    except TypeError:
        print("Error: Invalid sequence or codon_table provided")
        return ''

