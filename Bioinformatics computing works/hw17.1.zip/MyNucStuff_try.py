import sys

def read_seq_from_filename(seq_filename):
    try:
        with open(seq_filename) as f:
            dna_seq = ''.join(f.read().split()).upper()
        return dna_seq
    except FileNotFoundError:
        print('sequence file not found')
        sys.exit(1)

    except IOError:
        print("can't read sequene file")
        sys.exit(1)
    

compl_dict = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}

def complement(seq):
    try:
        return ''.join(compl_dict.get(base, 'N') for base in seq)
    except TypeError:
        print('Invalid sequence provided')
    except KeyError:
        print('Sequence contain unknown nuc')

def revseq(seq):
    try:
        return ''.join(reversed(seq))
    except TypeError:
        print("Error: Invalid sequence provided.")

def reverseComplement(seq):
    try:
        return complement(revseq(seq))
    except TypeError:
        print('Invalid sequence provided')

def is_reverse_complement_palindrome(primer):
    try:
        n = len(primer)
        halfn = n // 2
        first_half = primer[:halfn]
        second_half = primer[-halfn:]
        return first_half == reverseComplement(second_half)
    except TypeError:
        print('Invalid input')

def count_nucleotides(seq):
    try:
        counts = {'A': seq.count('A'),'T': seq.count('T'),'C': seq.count('C'),'G': seq.count('G')}
        return counts
    except TypeError:
        print('invalid input')

def gc_content(seq):
    try:
        counts = count_nucleotides(seq)
        gc_count = counts['G'] + counts['C']
        return (gc_count / len(seq)) * 100 if len(seq) > 0 else 0
    except TypeError:
        print('invalid input')

def tandem_repeats(seq):
    try:
        seq_length = len(seq)
        for size in range(1, seq_length // 2 + 1):
            if seq_length % size == 0:
                sub_seq = seq[:size]
                repeats = seq_length // size
                if sub_seq * repeats == seq:
                    return True
        return False
    except TypeError:
        print('invalid input')

def count_amino_acids(seq):
    try:
        return len(seq) // 3 - 1
    except TypeError:
        print('invalid input')

def find_start_codon(seq):
    try:
        start_codon = "ATG"
        position = seq.find(start_codon)
        return position + 1 if position != -1 else -1
    except TypeError:
        print('invalid input')








