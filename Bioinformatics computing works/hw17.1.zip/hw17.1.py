from MyNucStuff_try import *
from codon_table_try import *
import sys

try:
    table = read_codons_from_filename(sys.argv[1])
    seq = read_seq_from_filename(sys.argv[2])
    
except IndexError:
    print('Please provide a codon table and DNA sequence file on the command-line.')
    sys.exit(1)

except IOError as e:
    print('Can not find sequence file or codon table file')
    sys.exit(1)

# Forward
for frame in (1, 2, 3):
    print("Frame", frame, "(forward):", translate(table, seq, frame))

# Reverse
reverse_seq = reverseComplement(seq)
for frame in (1, 2, 3):
    print("Frame", frame, "(reverse):", translate(table, reverse_seq, frame))

