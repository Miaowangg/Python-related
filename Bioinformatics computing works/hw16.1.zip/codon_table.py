'''
Rework the lecture, and your solutions (or mine) from Homework #5
to make the codon_table module with functions specified in this lecture.
'''
def read_codons_from_filename(codonfile):
    data = {}
    with open(codonfile) as f:
        for line in f:
            sl = line.split()
            key = sl[0]
            value = sl[2]
            data[key] = value
    
    b1 = data['Base1']
    b2 = data['Base2']
    b3 = data['Base3']
    aa = data['AAs']
    st = data['Starts']

    codon_table = {}
    for i in range(len(aa)):
        codon = b1[i] + b2[i] + b3[i]
        is_init = (st[i] == 'M')
        codon_table[codon] = (aa[i], is_init)
    
    return codon_table

def amino_acid(codon_table, codon):
    return codon_table.get(codon, ('X', False))[0]

# Check if a codon is a start codon
def is_init(codon_table, codon):
    return codon_table.get(codon, (None, False))[1]

# Handle ambiguous codons (contains 'N')
def get_ambig_aa(codon_table, codon):
    if 'N' in codon:
        return 'X'
    return amino_acid(codon_table, codon)

# DNA seq --> AA seq
def translate(codon_table, seq, frame):
    seq = seq.upper()
    seq_len = len(seq)
    aaseq = []
    for i in range(frame - 1, seq_len, 3):
        codon = seq[i:i+3]
        if len(codon) == 3:
            aa = get_ambig_aa(codon_table, codon)
            aaseq.append(aa)
    return ''.join(aaseq)

