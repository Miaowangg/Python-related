from Bio.Blast import NCBIXML

result_handle = open('results.xml')

most_conserved_hits = set()
most_conserved_e = float('inf')

for blast_result in NCBIXML.parse(result_handle):
    best_hit = None
    best_evalue = float('inf')

    for alignment in blast_result.alignments:
        for hsp in alignment.hsps:
            if hsp.expect < 1e-5:
                if hsp.expect < best_evalue:
                    best_evalue= hsp.expect
                    best_hit= alignment.title
    if best_hit:
        print("***** Best Hit for the Query *****")
        print("Best Match:", best_hit)
        print("Best E-value:", best_evalue)
        if best_evalue < most_conserved_e:
            most_conserved_e = best_evalue
            most_conserved_hits ={best_hit}
        elif best_evalue == most_conserved_e:
            most_conserved_hits.add(best_hit)
    else:
        print("***** No Significant Match *****")
        print(alignment.title)
        print("No significant e value")

if most_conserved_hits:
    print("**** Most conserved protein ****")
    for hit in most_conserved_hits:
        print("Protein:", hit)
    print("E-value:", most_conserved_e)


