from model import *
import sys

if len(sys.argv) != 2:
    print("Need organism name in command line")
    sys.exit(1)

organism_name = sys.argv[1]

name_obj = Name.select(Name.q.name == organism_name).getOne(None)
if name_obj:
    taxonomy_obj = name_obj.taxa
    print(f"The scientific name for '{organism_name}' is: {taxonomy_obj.scientificName}")
else:
    print(f"No scientific name found for '{organism_name}'.")
