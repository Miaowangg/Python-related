#Convert your modules for DNA sequence to DNASeq class.
class DNASeq:
    def __init__(self, sequence="", name=""):
        self.seq = sequence.upper()
        self.name = name

    def read(self,filename):
        self.seq = ''.join(open(filename).read().split())
        
    def reverse(self):
        return self.seq[::-1]
    
    def complement(self):
        compl_dict = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
        return ''.join(map(compl_dict.get,self.seq))

    def reverse_complement(self):
        return ''.join(reversed(self.complement()))

    def length(self):
        return len(self.seq)
    
    def freq(self,nuc):
        return self.seq.count(nuc)

    def percentGC(self):
        gccount = self.freq('C') + self.freq('G')
        return 100*float(gccount)/self.length()

    def find_start_codon(self):
        start_codon = "ATG"
        position = self.seq.find(start_codon)
        return position + 1 if position != -1 else -1

    def __str__(self):
        asstr = ">"+self.name+"\n"+self.seq
        return asstr






