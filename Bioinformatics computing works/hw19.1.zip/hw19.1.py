from DNASeq import *
from CodonTable import *
import sys

if len(sys.argv) < 3:
    print("Require codon table and", \
          "DNA sequence on command-line.")
    sys.exit(1)

codon_file = sys.argv[1]
dna_seq = sys.argv[2]

codons = CodonTable()
codons.read(codon_file)

sequence = DNASeq()
sequence.read(dna_seq)

for frame in (1, 2, 3):
    print('Frame', frame, '(forward):', codons.translate(sequence.seq, frame))
    

reverse_seq = sequence.reverse_complement()
for frame in (1, 2, 3):
    print('Frame', frame, '(reverse):', codons.translate(reverse_seq, frame))

