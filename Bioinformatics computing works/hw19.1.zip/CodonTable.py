class CodonTable:
    def __init__(self):
        self.table = {}

    def read(self,filename):
        data = {}
        with open(filename) as f:
            for l in f:
                sl = l.split()
                key = sl[0]
                value = sl[2]
                data[key] = value
        b1 = data['Base1']
        b2 = data['Base2']
        b3 = data['Base3']
        aa = data['AAs']
        st = data['Starts']

        codon_table = {}
        for i in range (len(aa)):
            codon = b1[i] + b2[i] + b3[i]
            is_init = (st[i] == 'M')
            codon_table[codon] = (aa[i], is_init)
        self.table = codon_table

    def amino_acid(self, codon):
        return self.table.get(codon, ('X', False))[0]

    def is_init(self, codon):
        if codon in self.table:
            init = self.table[codon][1]
        else:
            init = False
        return init

    def get_ambig_aa(self, codon):
        if codon[0] == 'N':
            n1syms = 'ACGT'
        else:
            n1syms = codon[0]
        if codon[1] == 'N':
            n2syms = 'ACGT'
        else:
            n2syms = codon[1]
        if codon[2] == 'N':
            n3syms = 'ACGT'
        else:
            n3syms = codon[2]

        aas = set()
        for n1 in n1syms:
            for n2 in n2syms:
                for n3 in n3syms:
                    thecodon = n1 + n2 + n3
                    aas.add(self.amino_acid(thecodon))
        
        if len(aas) > 1:
            aa = 'X'
        else:
            aa = aas.pop()
        return aa
        return self.amino_acid(codon)

    def translate(self,seq,frame):
        aalist = []
        for i in range(frame - 1, len(seq), 3):
            codon = seq[i:i+3]
            if len(codon) == 3:
                if 'N' in codon:
                    aa = self.get_ambig_aa(codon)
                else:
                    aa = self.amino_acid(codon)
                aalist.append(aa)
        aaseq = ''.join(aalist)
        return aaseq
            




