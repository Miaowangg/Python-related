from Bio import Entrez
from Bio.Blast import NCBIWWW, NCBIXML

Entrez.email = 'mw1472@georgetown.edu'

handle = Entrez.esearch(db='protein', term="Homo sapiens[Organism] AND LIME1[gene Name] AND REFSEQ")
result = Entrez.read(handle)
handle.close()

protein_ids = result["IdList"]
print('RefSeq protein IDs:',protein_ids)

idlist = "\n".join(protein_ids)
#print(idlist)
result_handle = NCBIWWW.qblast("blastp","refseq_protein",
                               idlist,
                               entrez_query="Mus musculus[Organism]",
                               expect=1e-3)

blast_results = result_handle.read()
result_handle.close()

save_file = open("blast_results.xml", "w")
save_file.write(blast_results)
save_file.close()

#Filter the alignments for E-value at most 1e-5
with open("blast_results.xml") as result_handle:
    for blast_result in NCBIXML.parse(result_handle):
        best_hit = None
        best_e = float('inf')
        for desc in blast_result.descriptions:
            if desc.e <= 1e-5 and desc.e < best_e:
                best_hit = desc
                best_e = desc.e
        if best_hit:
            print('****Alignment****')
            print('Best query:', blast_result.query)
            print('Best sequence:', desc.title)
            print('Best e value:', desc.e)
    
    



