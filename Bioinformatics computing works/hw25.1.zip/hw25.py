import sys
from model import *
init()

try:
    organism_name = sys.argv[1]
except IndexError:
    print("Need a organism name")
    sys.exit(1)

try:
    n = Name.selectBy(name=organism_name).getOne(None)
    if not n:
        print("organism not found")
        sys.exit(1)
except SQLObjectNotFound:
    print(organism_name, "does not exist")
    sys.exit(1)

try:
    t = n.taxonomy
    if not t:
        print("No taxonomy entry found")
        sys.exit(1)
except SQLObjectNotFound:
    print("No taznomy entry found")
    sys.exit(1)

r = t
taxonomyLineage = []

while r is not None and r.taxid !=r.parent.taxid:
    taxonomyLineage.append(r.scientific_name)
    r = r.parent

taxonomyLineage.reverse()
print("Taxonomy lineage for '{}':".format(organism_name))
print(">".join(taxonomyLineage))

