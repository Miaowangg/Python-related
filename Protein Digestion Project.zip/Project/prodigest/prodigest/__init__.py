# -*- coding: utf-8 -*-
"""The prodigest package"""
