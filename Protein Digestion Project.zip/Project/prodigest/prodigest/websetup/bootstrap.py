# -*- coding: utf-8 -*-
"""Setup the prodigest application"""
from __future__ import print_function, unicode_literals
from prodigest import model


def bootstrap(command, conf, vars):
    """Place any commands to setup prodigest here"""

    # <websetup.bootstrap.before.auth

    # <websetup.bootstrap.after.auth>
