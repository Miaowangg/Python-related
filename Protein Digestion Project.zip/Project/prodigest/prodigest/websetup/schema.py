# -*- coding: utf-8 -*-
"""Setup the prodigest application"""
from __future__ import print_function

from tg import config


def setup_schema(command, conf, vars):
    """Place any commands to setup prodigest here"""
