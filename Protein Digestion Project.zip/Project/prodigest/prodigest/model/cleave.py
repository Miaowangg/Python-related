aa_mw = {'A': 71.04, 'C': 103.01, 'D': 115.03, 'E': 129.04, 'F': 147.07,
         'G': 57.02, 'H': 137.06, 'I': 113.08, 'K': 128.09, 'L': 113.08,
         'M': 131.04, 'N': 114.04, 'P': 97.05, 'Q': 128.06, 'R': 156.10,
         'S': 87.03, 'T': 101.05, 'V': 99.07, 'W': 186.08, 'Y': 163.06 }

def trypsin(sequence):
    cut_sites = []
    for i in range(len(sequence) - 1):
        if sequence[i] in ('K', 'R') and sequence[i + 1] != 'P':
            cut_sites.append(i + 1)
    return cut_sites

def lysc(sequence):
    cut_sites = []
    for i in range(len(sequence) - 1):
        if sequence[i] == 'K':
            cut_sites.append(i + 1)
    return cut_sites

def cnbr(sequence):
    cut_sites = []
    for i in range(len(sequence) - 1):
        if sequence[i] == 'M':
            cut_sites.append(i + 1)
    return cut_sites

def argc(sequence):
    cut_sites = []
    for i in range(len(sequence) - 1):
        if sequence[i] == 'R' and sequence[i + 1] != 'P':
            cut_sites.append(i + 1)
    return cut_sites

def pepsin(sequence):
    cut_sites = []
    for i in range(len(sequence) - 1):
        if sequence[i] in ('F', 'L', 'Y'):
            cut_sites.append(i + 1)
    return cut_sites

##
def calculate_mw(peptide):
    return round(sum(aa_mw.get(aa, 0.0) for aa in peptide)+19, 2)

def missed_cleavages(sequence, cut_sites, max_missed_cleavage):
    cut_sites = [0] + cut_sites + [len(sequence)]
    peptides = []
    for missed in range(max_missed_cleavage + 1):
        for i in range(len(cut_sites) - 1 - missed):
            start = cut_sites[i]
            end = cut_sites[i + 1 + missed]
            peptide = sequence[start:end]
            if peptide:
                peptides.append({"peptide": peptide, "missed_cleavages": missed,
                                 "start": start, "end":end, "position":f"{start+1}-{end}"})
    return peptides

def digest_protein(sequence, enzyme_function, max_missed_cleavage=0):
    cut_sites = enzyme_function(sequence)
    peptides = missed_cleavages(sequence, cut_sites, max_missed_cleavage)
    return peptides

def filter_by_length(peptides, min_length, max_length):
    filtered_peptides = []
    for peptide_info in peptides:
        peptide = peptide_info["peptide"]
        if min_length <= len(peptide) <= max_length:
            filtered_peptides.append(peptide_info)
    return filtered_peptides

def filter_by_molecular_weight(peptides, min_weight, max_weight):
    filtered_peptides = []
    for peptide_info in peptides:
        peptide = peptide_info["peptide"]
        mw = calculate_mw(peptide)
        if min_weight <= mw <= max_weight:
            filtered_peptides.append(peptide_info)
    return filtered_peptides


















