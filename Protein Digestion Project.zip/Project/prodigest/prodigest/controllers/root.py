
# -*- coding: utf-8 -*-
from tg import expose, flash, require, url, lurl
from tg import request, redirect, tmpl_context
from tg.i18n import ugettext as _, lazy_ugettext as l_
from tg.exceptions import HTTPFound

from prodigest.lib.base import BaseController
from prodigest.controllers.error import ErrorController

import tw2.forms as twf
from prodigest.model.cleave import *

__all__ = ['RootController']

from tg import validate
from formencode import validators, compound, schema

class SearchFormValidator(schema.Schema):
    sequence = compound.All(validators.Regex(r'^ *[ACDEFGHIKLMNPQRSTVWYacdefghiklmnpqrstvwy]* *$'),
                            validators.PlainText(),
                            validators.String(min=2, strip=True))
    enzyme = validators.OneOf(['Trypsin', 'LysC', 'CNBr', 'ArgC', 'Pepsin'])
    min_length = validators.Int(min=0)
    max_length = validators.Int(min=0)
    min_weight = validators.Number(min=0)
    max_weight = validators.Number(min=0)
    max_missed_cleavage = validators.Int(min=0, max=5)

class SearchForm(twf.Form):
    class child(twf.TableLayout):
        sequence = twf.TextField(label='Protein Sequence')
        enzyme = twf.SingleSelectField(label='Enzyme',
                                       options=['Trypsin', 'LysC', 'CNBr', 'ArgC', 'Pepsin'],
                                       prompt_text='Select an Enzyme')
        min_length = twf.TextField(label='Minimum Peptide Length')
        max_length = twf.TextField(label='Maximum Peptide Length')
        min_weight = twf.TextField(label='Minimum Molecular Weight')
        max_weight = twf.TextField(label='Maximum Molecular Weight')
        max_missed_cleavage = twf.TextField(label='Missed Cleavages(0-5)')

        css_class = 'table'
        attrs = {'style': 'width: 600px;'}
        
    action = '/search'
    submit = twf.SubmitButton(value='Search')
    validator = SearchFormValidator

class RootController(BaseController):

    @expose('prodigest.templates.index')
    def index(self, **kwargs):
        return dict(title="Protein Digestion", form=SearchForm)

    @expose('prodigest.templates.search')
    @validate(SearchForm, error_handler=index)
    def search(self,sequence, enzyme, min_length, max_length, min_weight, max_weight, max_missed_cleavage):
        try:
            min_length = int(min_length)
            max_length = int(max_length)
            min_weight = float(min_weight)
            max_weight = float(max_weight)
            max_missed_cleavage = int(max_missed_cleavage)
        except ValueError:
            flash("please enter a valid number")
            return redirect(url('/index'))

        if min_length > max_length:
            flash("Minimum length cannot be greater than maximum length")
            return redirect(url('/index'))

        if min_weight > max_weight:
            flash("Minimum molecular weight cannot be greater than maximum molecular weight")
            return redirect(url('/index'))

        enzyme_functions = {
            'Trypsin': trypsin,
            'LysC': lysc,
            'CNBr': cnbr,
            'ArgC': argc,
            'Pepsin': pepsin,
        }

        if enzyme not in enzyme_functions:
            flash("Invalid enzyme selected")
            return redirect(url('/index'))


        enzyme_function = enzyme_functions[enzyme]
        peptides = digest_protein(sequence, enzyme_function, max_missed_cleavage)
        peptides = filter_by_molecular_weight(peptides, min_weight, max_weight)
        peptides = filter_by_length(peptides, min_length, max_length)


        if not peptides:
            flash("No peptides found matching the specified filters.")
            return redirect(url('/index'))

        results = []
        for peptide_info in peptides:
            peptide = peptide_info["peptide"]
            start = peptide_info["start"]
            end = peptide_info["end"]
            if start > 0 :
                n_aa = sequence[start-1]
            else:
                n_aa = '-'

            if end < len(sequence):
                c_aa = sequence[end]
            else:
                c_aa = '-'

            results.append({"peptide" : peptide,
                            "length" : len(peptide),
                            "molecular_weight" : calculate_mw(peptide),
                            "missed_cleavages" : peptide_info["missed_cleavages"],
                            "position" : peptide_info["position"],
                            "C-terminal Amino Acid" : c_aa,
                            "N-terminal Amino Acid" : n_aa,
                            })

        return dict(title='Peptides Results',results=results, enzyme=enzyme)
                








