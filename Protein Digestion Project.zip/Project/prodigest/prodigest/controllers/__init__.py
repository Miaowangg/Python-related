# -*- coding: utf-8 -*-
"""Controllers for the prodigest application."""
